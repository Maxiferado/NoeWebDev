<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aprediendo PHP</title>
    <link rel="stylesheet" href="/css/phpcss.css">  
</head>
<body>
    <div class="contenedor">
        <h1>Aprendiendo PHP</h1>
    </div>
    <div class="contenido">
        <?php
           /* $hola = "hola mundo";
            echo $hola;
            $numero = 20;
            echo $numero;

            $saludos = "<h1>hola hi</h1>";
            echo $saludos; */
            ////////////////////////////////////////////////////////////////////////////////
            //                  Concatenar Php Es con puntos                              //
            ///////////////////////////////////////////////////////////////////////////////
            /* $nombre = "Diego Alejandro";
            $apellido = "Jaime Baron";
            $edad = 23;
            echo $nombre . " " . $apellido . " " . $edad;
             */          
        ?>
    </div>
    <div class="video4" id ="Formas de escribir php+html">
        <?php
           $nombre = "Diego Alejandro";
           $apellido = "Jaime Baron";               
            echo "<h1>{$nombre} {$apellido}</h1>";        
        ?>        
        <h1><?php echo $nombre . " " . $apellido ?></h1>   
    </div>
    <div class="video5">
        <?php 
                $titulo = "Apendiendo Php";
        ?>
        <p><?php echo $titulo; ?></p>       
    </div>
    <div class="video8" id = "SwitchCases">
        <?php 
        $lenguaje = "HTML";
        switch($lenguaje){
            case "Php": 
                echo "BackEnd";
                break;
            case "JavaScript":
                echo "FrontEnd y Back End (NodeJS)";
                break;
            case "HTML":
                echo "Front End";
                break;
            default:
                echo "no valido";
                break;
        }
        ?>
    </div>
    <div class="video9" id="Arrays">
        <?php 
        $nombre = array("diego","alvaro","jose","valencia");
        echo $nombre[3];     
        ?>
    </div>
    <div class="video10" id = "PrintRyvar_dum">
       <pre>
         <?php 
        $nombre = array("diego","alvaro","jose","valencia");
        print_r($nombre)
        ?>      
       </pre>
        <pre>
            <?php 
             $nombre = array("diego","alvaro","jose","valencia", 20);
             var_dump($nombre);
            ?>
        </pre>
    </div>
    <div class="video11">
        <pre>
        <?php 
        $tecnologias = array("CSS","HTML","jQuery","Php","MySQL","C#","Phyton");
        var_dump($tecnologias);
        $tecnologias[] =  "c++";
        var_dump($tecnologias);
        ?>
        <?php //Borrar Ultimo Elemento y Almacenarlo En Una Varible?>
        <?php $CSS = array_pop($tecnologias);?>        
        <?php echo $CSS ." <----- Array_pop Para extraer el ultimo elmeneto del arreglo"; ?>
        <hr>
        <?php unset($tecnologias[0]);
             var_dump($tecnologias);             
        ?>
        <?php echo" <----- unset(Array[x]) Para extraer el x posicion del arreglo en este caso el 0"; ?>
        <hr>
        <?php// Remover primer elemento y agregarlo a variable?>
        <?php $html = array_shift($tecnologias);
        var_dump($tecnologias);        
        ?>
        <?php echo $html ." <----- Array_shift Para extraer el Primer elmeneto del arreglo"; ?>
        <hr>
        
        <?php// Remover Ciertos elemento y agregarlo Otros?>
        <?php $html = array_shift($tecnologias);
        var_dump($tecnologias);        
        ?>
        <?php echo $html ." <----- Array_shift Para extraer el Primer elmeneto del arreglo"; ?>
        </pre> 
        




    </div>
</body>
</html>